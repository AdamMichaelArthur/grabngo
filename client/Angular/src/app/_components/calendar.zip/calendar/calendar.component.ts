import {
  Component, OnInit, ElementRef, ViewChild, ViewChildren,
  ViewContainerRef,
  ComponentFactoryResolver,
  ComponentRef,
  ComponentFactory,
  EventEmitter, Output
} from '@angular/core';

import { CalendarItemComponent } from './calendar-cell/calendar-item/calendar-item.component'
import { CalendarService } from './calendar.service';
import * as moment from 'moment';
import { range } from 'rxjs';
import { map } from 'rxjs/operators';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})

export class CalendarComponent implements OnInit {

  rows = [0, 7, 14, 21, 28];
  columns = [1, 2, 3, 4, 5, 6, 7];
  namesOfDays = moment.weekdaysShort()
  currentDate
  weeks
  dates
  selectedEndWeek
  selectedStartWeek
  prevMonthDate
  nextMonthDate

  // Observable, this works just like other observables
  // The calendar cells are "subscribing" to this
  public recvCalendarItem: EventEmitter<object> = new EventEmitter();
  public closeMenusEvent: EventEmitter<boolean> = new EventEmitter();

  constructor(public service: CalendarService) {
  }


  ngOnInit() {
    this.currentDate = moment();
    this.generateCalendar();
  }

  hideAllMenus() {

    this.closeMenusEvent.emit(true);
  }

  populateCalendarCells(data) {

    // This is hardcoded for 'bounty' but will be changed to be any datasource
    // This is the information we got from the backend.
    var bounties = data["bounty"];

    for (var i = 0; i < bounties.length; i++) {
      var bounty = bounties[i];
      var date = moment(bounty["release_for_bounty"]).format('YYYY-MM-DD')

      // We are emitting an event and sending it to ALL calendar calendarCells
      // This may nto be the most effecient, but it's a decent solution for a first
      // version / proof of concept
      // What this allows us to do is maintain our data state without using complicated
      // nested arrays or some other way.
      // console.log(bounty.process)
      this.recvCalendarItem.emit({
        ...bounty,
        ... {
          "isodate": date,  // THis is the date of the bounty, but in the -YYYY-MM-DD format
          "_dateKey": "release_for_bounty",
          "_dateValue": bounty["release_for_bounty"],
          "bMenu": false,
          "key": "step",
          "distinct": "content_type"
        }
      });
    }
  }

  private generateCalendar(): void {
    this.dates = []
    this.dates = this.fillDates(this.currentDate);
    this.weeks = [];
    while (this.dates.length > 0) {
      var sevenDays = this.dates.splice(0, 7)
      this.weeks.push(sevenDays);
    }

    // I'm getting the 1st day of the month and the last day of the month
    // and putting it into a format that can be sent to getDatesBetween
    var begin = this.currentDate.format("YYYY-MM-01");
    var end = this.currentDate.format("YYYY-MM-") + moment().daysInMonth();

    this.service.getBetweenDates(begin, end).subscribe(
      (data: any) => {
        // console.log(data)
        this.populateCalendarCells(data)
      },
      (error) => {
        // console.log(40, "Error", error);
      })
  }

  private fillDates(currentMoment: moment.Moment) {
    var firstOfMonth = moment(currentMoment).startOf('month');
    var lastOfMonth = moment(currentMoment).endOf('month');

    var firstIndexOfGrid = firstOfMonth.day()
    var lastIndexOfGrid = lastOfMonth.day()

    var days = [];
    var day = firstOfMonth;
    var dayObject = {}

    var prevDay
    for (let i = firstIndexOfGrid; i > 0; i--) {
      prevDay = moment(firstOfMonth).subtract(i, 'days');
      // console.log("previous day: " + prevDay.toDate())
      dayObject = {
        "date": prevDay.toDate(),
        "isodate": prevDay.toISOString()
      }
      // days.push(prevDay.toDate());
      days.push(dayObject);
    }
    while (day <= lastOfMonth) {

      // days.push(day.toDate());
      //console.log(123, typeof day, )
      var theDay = day.format('YYYY-MM-DD')
      // console.log(125, theDay)
      dayObject = {
        "date": day.toDate(),
        "isodate": theDay
      }
      days.push(dayObject);

      day = day.clone().add(1, 'd');
    }
    var nextDay
    if (6 - lastIndexOfGrid !== 0) {
      for (let i = 1; i < 7 - lastIndexOfGrid; i++) {
        nextDay = moment(lastOfMonth).add(i, 'days');
        // console.log("previous day: " + nextDay.toDate())
        // days.push(nextDay.toDate());
        dayObject = {
          "date": nextDay.toDate(),
          "isodate": moment(day).toISOString()
        }
        days.push(dayObject);
      }
    }

    return days
  }

  private isToday(date: moment.Moment): boolean {
    return moment().isSame(moment(date), 'day');
  }

  private isSelected(date: moment.Moment): boolean {
    return moment(date).isBefore(this.selectedEndWeek) && moment(date).isAfter(this.selectedStartWeek)
      || moment(date.format('YYYY-MM-DD')).isSame(this.selectedStartWeek.format('YYYY-MM-DD'))
      || moment(date.format('YYYY-MM-DD')).isSame(this.selectedEndWeek.format('YYYY-MM-DD'));
  }

  public isDayBeforeLastSat(date: moment.Moment): boolean {
    const lastSat = moment().weekday(-1);
    return moment(date).isSameOrBefore(lastSat);
  }

  public prevMonth(): void {
    this.currentDate = moment(this.currentDate).subtract(1, 'months');
    // console.log("previous Month: " + this.currentDate)
    this.generateCalendar();
  }

  public nextMonth(): void {
    this.currentDate = moment(this.currentDate).add(1, 'months');
    // console.log("next Month: " + this.currentDate)
    this.generateCalendar();
  }

  public isDisabledMonth(currentDate): boolean {
    const today = moment();
    return moment(currentDate).isBefore(today, 'months');
  }

  public isSelectedMonth(date: moment.Moment): boolean {
    const today = moment();
    return moment(date).isSame(this.currentDate, 'month') && moment(date).isSameOrBefore(today);
  }

  dropEvent(event) {
    var data = event.dataTransfer.getData("taskItem");
    var _id = event.dataTransfer.getData("_id");
    var _dateKey = event.dataTransfer.getData("_dateKey");
    var _dateValue = event.dataTransfer.getData("_dateValue");
    var element = document.getElementById(data);
    var droppedDate = event.target.attributes["data-isodate"].value; // the date of the cell that was droppped.  I stored it as a data-attirbute in the html

    event.target.appendChild(element);
    element.removeAttribute('id');
    event.srcElement.style = ""

    // I need to know what the date of the cell that the item was dropped into
    // I need ti know the date of the cell that the item was dropped from
    // and I need the _id of the mongoDC document to update.

    this.service.updateDate("bounty", _id, _dateKey, moment(droppedDate).format("YYYY-MM-DD"))
      .subscribe(
        (data: any) => {
          // console.log(205, data)
        },
        (error) => {
          // console.log(40, "Error", error);
        })
  }

  allowDrop($event) {
    $event.preventDefault()
    $event.srcElement.style = "background-color:red; opacity:0.50;"
  }

  dragLeave($event) {
    $event.srcElement.style = ""
  }

}
