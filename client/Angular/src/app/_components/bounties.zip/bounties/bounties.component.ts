import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

import { BaseComponent } from '../base/base.component';
import { BaseService } from '../base/base.service'
import { SharedService } from '../../_services/shared.service'
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Router, NavigationExtras } from '@angular/router'
import { BountyCreateComponent } from './bounty-create/bounty-create.component';

interface Frequency {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-bounties',
  templateUrl: './bounties.component.html',
  styleUrls: ['./bounties.component.css']
})

export class BountiesComponent extends BaseComponent implements OnInit {

  viewMode = 'process';
  data:any = [];
  sections: any;

  filters = [
    {
      "filter": { "media_type":"$media_type" },
      "label": "Content Type",
      "valueKeys": [],
      "valueIds": [],
      "datasource": "media",
      "key": "media_type",
      "distinct": "media_format"
    },
    {
      "filter": false,
      "label": "Brand",
      "valueKeys": [],
      "valueIds": [],
      "datasource": "brand",
      "key": "brand_name",
      "distinct": "brand_name",
      "all":false
    }
  ]

  constructor(
    public service: BaseService, 
    public elementRef: ElementRef, 
    public sharedService: SharedService, 
    public router: Router) {
    super(service, elementRef) 
  }

  monthly_budget: any = "0";

  hideTableButtonArea(){
    
    console.log("Override default behavior");

  }

  ngOnInit(){
    super.ngOnInit();
    this.data = [
      {
        process: true,
        process_lable:"Step 1",
        process_desc:"Simple Description...",
        inhouse:true,
        checkin:false
      },
      {
        process: false,
        process_lable:"Step 2",
        process_desc:"Simple Description...",
        inhouse:false,
        checkin:true
      },
      {
        process: false,
        process_lable:"Step 3",
        process_desc:"Simple Description...",
        inhouse:true,
        checkin:false
      }
    ]
  }

  brands = [];
  ngAfterViewInit() {
    this.service.getDistinctArrayWithIds("brands", "brand_name", false).subscribe((data: any) => {
         this.brands = data;
         console.log(92, this.brands);
    })
  }

  isApproved:boolean = false;
  inhouseUsers = []
  content_type: any;
  tableButtonClicked($event){
    console.log(62, this.response);
    this.response = $event;
    // The response should include a process name to get
    if($event.button == "Add"){
      if(this.currentBrand == ""){
        alert("Please Select A Brand First");
        return;
      }

      if($event.bounty.frequency == "Select Frequency"){
        alert("Please Select A Frequency First...");
        return;
      }

      if($event.bounty.starting_day == "Select Day"){
        alert("Please Select the Day you want to start");
        return;
      }

      // get content Type
      this.content_type = $event.content_type;
      var sections = []
      this.inhouseUsers = []
      this.monthly_budget = $event.message;
      console.log(128, $event.bounty)
      this.currentBounty = $event.bounty;
      this.currentBounty.brand_name = ""
      console.log(130, this.currentBounty)
      this.displayTableButtonArea = true;

      // this.router.navigate(['/create-bounty', {content_type: content_type}])
      // this.router.navigate(['/create-bounty'], { queryParams: { content_type: content_type, monthly_budget: this.monthly_budget, currentBounty: this.currentBounty } });
      
      // this.service.getArray("step", {"content_type":content_type}, true, 100).subscribe((data: any) => {   
      //     this.data = [];

      //     this.service.getAllUsersForAccount("users").subscribe(
      //       (response: any)=>{
      //         console.log(118, response)
      //         for(var i=0; i<response.length; i++)
      //         {
      //           var obj = {}
      //           obj["_id"] = response[i]["_id"]
      //           obj["email"] = response[i]["email"]
      //           obj["first_name"] = response[i]["first_name"]
      //           obj["last_name"] = response[i]["last_name"]
      //           this.inhouseUsers.push(obj)
      //         }
      //         console.log(130, this.inhouseUsers)
      //       })

      //     for(var i = 0; i < data.length; i++){
      //               var processRow = {}
      //               processRow["process"] = false;
      //               processRow["inhouse"] = false;
      //               processRow["inhouseUser"] = [];
      //               processRow["checkin"] = false;
      //               processRow["checkInUser"] = [];
      //               processRow = Object.assign(processRow, data[i])
      //               this.data.push(processRow);
      //               sections.push(data[i].stage)
      //     }
      //     this.sections = new Set(sections);
      //     console.log(125, this.sections);
      //     console.log(126, this.data);
      //   }) 

      // this.add($event)
      // super.tableButtonClicked($event);
      return;
    }
    super.tableButtonClicked($event);
  }

  flextableHeaderButtonClicked(event){
    
    if(event == "Start Over"){
      this.service.dynamicButton("process", "StartOver", "startover").subscribe(
              (data: any) => {
                 this.monthly_budget = "0";
              }
            )
      return;

    }

    if(event == "Unused Keywords"){
      // We want to create bounties based on our unused keywords
      // Display a 

      if(this.currentBrand == ""){
        alert("Please Select A Brand First");
        return;
      }

      var filter = {
        "brand_name":this.currentBrand,
        "bKeywordDeployed": {$ne: true }
      }
  
      this.unusedKeywords = true;
      this.inhouseUsers = []
      var content_type = "Long Form Article";
      var sections = []
      this.service.getArray("step", {"content_type":content_type}, true, 100).subscribe((data: any) => {   
          this.data = [];
          this.service.getAllUsersForAccount("users").subscribe(
            (response: any)=>{
              console.log(118, response)
              for(var i=0; i<response.length; i++)
              {
                var obj = {}
                obj["_id"] = response[i]["_id"]
                obj["email"] = response[i]["email"]
                obj["first_name"] = response[i]["first_name"]
                obj["last_name"] = response[i]["last_name"]
                this.inhouseUsers.push(obj)
              }
              console.log(130, this.inhouseUsers)
            })
          for(var i = 0; i < data.length; i++){
                    var processRow = {}
                    processRow["process"] = false;
                    processRow["inhouse"] = false;
                    processRow["inhouseUser"] = [];
                    processRow["checkin"] = false;
                    processRow["checkInUser"] = [];
                    processRow = Object.assign(processRow, data[i])
                    this.data.push(processRow);
                    sections.push(data[i].stage)
          }
          this.sections = new Set(sections);
        })

      return;
    }

    if(event == "Approve All"){
      if(this.bountyTemplate.length == 0){
        alert("Please Add A Bounty Before Trying to Approve Them");
        return;
      }

      this.isApproved = true;

      // Parse and create the bounties
      this.service.headerButton("bounty", "createbounties", this.bountyTemplate).subscribe(
              (data: any) => {
                 var brand_id = 0;
                 //console.log(122, "Response", data);
                 console.log(152, this.brands);
                 for(var i = 0; i < this.brands.length; i++){
                   if(this.brands[i].brand_name == this.currentBrand){
                     brand_id = this.brands[i]["_id"]
                   }
                 }
                 let navigationExtras: NavigationExtras = {
                      queryParams: {
                        "batch":data.actions.batch,
                         "brand_name":this.currentBrand,
                         "brand_id":brand_id
                      }
                  };
                  console.log(235, navigationExtras);

                 var info = {
                   "batch":data.actions.batch,
                   "brand_name":this.currentBrand,
                   "brand_id":brand_id
                 }
                 this.isApproved = false;
                 this.router.navigate(["/addkeyword"], navigationExtras);
              }
            )
      return;
    }

    super.flextableHeaderButtonClicked(event);

  }


  headerDropdownChanged($event){
    console.log(146, "A header button changed", $event.value);
    this.currentBrand = $event.value;
  }

  currentBrand: any = "";
  currentBounty: any = {}

  add($event){

    console.log(32, $event);
    this.monthly_budget = $event.message;
    this.currentBounty = $event.bounty;
  }

  // Editorial Guidelines
  dropboxLinkInput: any
  dropboxLink: any = [];
  addDropBox(link: string) {
    this.dropboxLink.push(link);
    this.dropboxLinkInput = null
  }
  deleteDropboxLink(link:string){
    const index: number = this.dropboxLink.indexOf(link);
    if (index !== -1) {
      this.dropboxLink.splice(index, 1)
    }
  }
  // Editorial Guidelines

  // Prompt Bucket
  promptLists: any = [];
  volume = 0;
  clicks = 0;

  deletePrompt(prompt: string) {
    const index: number = this.promptLists.indexOf(prompt);
    if (index !== -1) {
      for(var i = 0; i < this.keywordsAr.length; i++){

        if(this.keywordsAr[i]["Keyword"] == this.promptLists[index]){
          console.log(147, this.keywordsAr[i], this.promptLists[index])

          if(this.keywordsAr[i]["Clicks"] != 'undefined'){
            if(Number.isNaN(parseInt(this.keywordsAr[i]["Clicks"])) == false){
              this.clicks -= parseInt(this.keywordsAr[i]["Clicks"]);
            } 
          }

          if(this.keywordsAr[i]["Volume"] != 'undefined'){
            if(Number.isNaN(parseInt(this.keywordsAr[i]["Volume"])) == false){
              this.volume -= parseInt(this.keywordsAr[i]["Volume"])
            } 
          }

        }
      }
      this.promptLists.splice(index, 1)
    }
  }
  // Prompt Bucket end

  // initiating inhouse user

  onCheckinHouse(event, i){
    if(event.target.checked){
      this.data[i].inhouseUser = 0
      console.log(304, this.data[i].inhouseUser, this.inhouseUsers[0])
    }
  }

  // initiating inhouse user end

  // initiating checkin user

  onCheckcheckIn(event, i){
    if(event.target.checked){
      this.data[i].checkinUser = 0
      console.log(315, this.data[i].checkinUser, this.inhouseUsers[0])
    }
  }

  // initiating checkin user end

  //Save Guidelines
  additional_instruction:string = "";

  bountyTemplate: Array<any> = [];

  addGuide($event){
    this.reset();
    // var steps = [];
    // var stepOrder = 0;
    // var content_type = "";
    // for(var i = 0; i < this.data.length; i++){
    //   const process_step = this.data[i];

    //   if(process_step.process == true){
    //     stepOrder++;
    //     var step = {}
    //     content_type= process_step["content_type"]
    //     step["completion_order"] = stepOrder;
    //     step["name"] = process_step["step"];
    //     step["description"] = process_step["step_description"];
        
    //     if(process_step["inhouse"] != false){
    //       //console.log(319, ObjectID(this.inhouseUsers[process_step["inhouseUser"]]["_id"]))
    //       // step['inhouse'] = this.inhouseUsers[process_step["inhouseUser"]] ? this.inhouseUsers[process_step["inhouseUser"]]["_id"] : this.inhouseUsers[0]["_id"]
    //       step['inhouse'] = this.inhouseUsers[process_step["inhouseUser"]]["_id"]
          
    //       console.log(347, step['inhouse'])
    //     }
    //     else 
    //     {
    //       step['inhouse'] = false;
    //     }

    //     if(process_step["checkin"] != false){
    //       //console.log(319, ObjectID(this.inhouseUsers[process_step["inhouseUser"]]["_id"]))
    //       // step['inhouse'] = this.inhouseUsers[process_step["inhouseUser"]] ? this.inhouseUsers[process_step["inhouseUser"]]["_id"] : this.inhouseUsers[0]["_id"]
    //       step['checkin'] = this.inhouseUsers[process_step["checkinUser"]]["_id"]
          
    //       console.log(359, step['checkin'])
    //     }
    //     else 
    //     {
    //       step['checkin'] = false;
    //     }

    //     //step["inhouse"] = process_step["inhouse"];
    //     step["inhouseUser"] = this.inhouseUsers[process_step["inhouseUser"]];
    //     step["checkinUser"] = this.inhouseUsers[process_step["checkinUser"]];
    //     step["skills"] = process_step["skills"];
    //     step["files"] = process_step["files"];
    //     step["bounty"] = process_step["bounty"];
    //     step["pipeline"] = "unclaimed";
    //     step["status"] = "incomplete";
    //     step["bStatus"] = false;
    //     if(stepOrder == 1){
    //       step["bStatus"] = true;
    //     }
    //     steps.push(step);
    //     // console.log(330, JSON.stringify(step["inhouseUser"].first_name))
    //   }
    // }

    console.log(430, this.currentBounty)
    this.currentBounty.brand_name = this.currentBrand;
    // const addProcess = {
    //   content_type: content_type,
    //   dropboxLink: this.dropboxLink,
    //   promptLists: this.promptLists,
    //   additional_instruction: this.additional_instruction,
    //   process:steps,
    //   bounty:this.currentBounty
    // }

    const addProcess = $event

    // console.log(this.currentBounty)

    // addProcess.bounty = JSON.parse(this.currentBounty)
    console.log(448, addProcess)
    addProcess.bounty = this.currentBounty[0]
    console.log(450, addProcess.bounty.brand_name)

    this.bountyTemplate.push(addProcess);
    this.hideBounty()
  }

  //Save Guidelines

    // We are receiving a drop from the flextable
    keywordsAr: Array<any> = [];
  drop(event: CdkDragDrop<string[]>) {
      //this.sharedService.drop(event);
      var dropData = event.previousContainer.data[event.previousIndex];
      
      console.log(167, event.currentIndex);

      console.log(168, event);

      this.promptLists.push(event.previousContainer.data[event.previousIndex]["Keyword"]);
      this.keywordsAr.push(dropData);

      if(dropData["Clicks"] != 'undefined'){
        if(Number.isNaN(parseInt(dropData["Clicks"])) == false){
          this.clicks += parseInt(dropData["Clicks"]);
        } 
      }
      if(dropData["Volume"] != 'undefined'){
        if(Number.isNaN(parseInt(dropData["Volume"])) == false){
          this.volume += parseInt(dropData["Volume"])
        } 
      }
  }

  total_bounty: number = 0;

  updateBountyTotal($event, process_step){
    var newValue = 0;
    if($event.length == 0)
      newValue = 0;
    else
      newValue = parseInt($event);
  
    var lastArPos = process_step["previous_values"].length-1;
    
    this.total_bounty -= process_step["previous_values"][lastArPos]
    process_step["previous_values"].push(newValue)
    //process_step.previous_value = newValue;

    this.total_bounty += newValue;
    //var newValue = parseInt($event.srcElement.value);
    //this.total_bounty -= process_step.bounty;
    //this.total_bounty += newValue;
    //process_step.bounty = newValue
  }

  reset(){
    this.total_bounty = 0;

  }

  stepChecked(process_step){
    process_step["previous_values"] = [];
    process_step["previous_values"].push(process_step.bounty)
    if(process_step.process){
      process_step.bounty = process_step.suggested_bounty;
      this.total_bounty += process_step.bounty;
    }
    else {
      this.total_bounty -= process_step.bounty;
      process_step.bounty = 0;
    }
    process_step["previous_values"].push(process_step.bounty)
  }

  getUnusedKeywords(){

  }

  unusedKeywords: boolean = false
  frequencies: Frequency[] = [
    {value: 'once', viewValue: 'One Time'},
    {value: '2xDay', viewValue: 'Two Times Per Day'},
    {value: '3xDay', viewValue: 'Three Times Per Day'},
    {value: '4xDay', viewValue: 'Four Times Per Day'},    
    {value: 'daily', viewValue: 'Daily'},
    {value: '2xWeek', viewValue: 'Every Other Day'},
    {value: '3xWeek', viewValue: 'Every Third Day'},
    {value: '4xWeek', viewValue: 'Every Fourth Day'},
    {value: '5xWeek', viewValue: 'Every Fifth Day'},
    {value: '6xWeek', viewValue: 'Every Sixth Day'},
    {value: '1xWeek', viewValue: 'Once Per Week'},
    {value: '2xMonth', viewValue: 'Every Other Week'},
    {value: '1xMonth', viewValue: 'Once Per Month'}
  ];

  selected: any = ''
  myDate: any
  isLoading:boolean = false
  
  test(i){

    this.data[i].inhouseUser[0] = this.inhouseUsers[0]
    console.log(446, "test", this.data[i].inhouseUser, this.inhouseUsers[0])  
  }

  initUsers(){
    //var proc = this.data[i]
    console.log(451, this.data)
  }

  createBountiesByUnusedKeywords(){
    this.isLoading = true;
    this.unusedKeywords = false;
    var steps = [];
    var stepOrder = 0;
    var content_type = "";

    for(var i = 0; i < this.data.length; i++){
      const process_step = this.data[i];

      if(process_step.process == true){
        stepOrder++;
        var step = {}
        content_type= process_step["content_type"]
        step["completion_order"] = stepOrder;
        step["name"] = process_step["step"];
        step["description"] = process_step["step_description"];
        if(process_step["inhouse"] != false){
          //console.log(319, ObjectID(this.inhouseUsers[process_step["inhouseUser"]]["_id"]))
          // step['inhouse'] = this.inhouseUsers[process_step["inhouseUser"]] ? this.inhouseUsers[process_step["inhouseUser"]]["_id"] : this.inhouseUsers[0]["_id"]
          step['inhouse'] = this.inhouseUsers[process_step["inhouseUser"]]["_id"]
          
          console.log(347, step['inhouse'])
        }
        else 
        {
          step['inhouse'] = false;
        }

        if(process_step["checkin"] != false){
          //console.log(319, ObjectID(this.inhouseUsers[process_step["inhouseUser"]]["_id"]))
          // step['inhouse'] = this.inhouseUsers[process_step["inhouseUser"]] ? this.inhouseUsers[process_step["inhouseUser"]]["_id"] : this.inhouseUsers[0]["_id"]
          step['checkin'] = this.inhouseUsers[process_step["checkinUser"]]["_id"]
          
          console.log(359, step['checkin'])
        }
        else 
        {
          step['checkin'] = false;
        }

        //step["inhouse"] = process_step["inhouse"];
        step["inhouseUser"] = this.inhouseUsers[process_step["inhouseUser"]];
        step["checkinUser"] = this.inhouseUsers[process_step["checkinUser"]];
        step["skills"] = process_step["skills"];
        step["bounty"] = process_step["bounty"];
        step["files"] = process_step["files"];
        step["pipeline"] = "unclaimed";
        step["status"] = "incomplete";
        step["bStatus"] = false;
        if(stepOrder == 1){
          step["bStatus"] = true;
        }
        steps.push(step);
      }
    }
    var postBody = {
      "brand_name":this.currentBrand,
      "starting_day":this.myDate,
      "frequency":this.selected,
      "process":steps
    }

    // This should be enough to post the bounties...
    this.service.headerButton("bounties", "bountiesfromkeywords", postBody).subscribe(
              (data: any) => {
                 console.log(122, "Response", data);
                 this.isLoading = false
                 
                 this.router.navigate(["/calendar"]);
              }
            )

  }

  disapparePopup(){
    this.displayTableButtonArea = false
    // this.unusedKeywords = !this.unusedKeywords
  }
  disapparePopup2(){
    this.unusedKeywords = false
  }

}
